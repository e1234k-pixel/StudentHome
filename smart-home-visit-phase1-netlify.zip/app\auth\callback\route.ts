import { NextResponse } from "next/server"

import { getSupabaseEnv } from "@/lib/supabase/env"
import { createServerSupabaseClient } from "@/lib/supabase/server"

function getSafeNextPath(next: string | null) {
  if (!next || !next.startsWith("/")) {
    return "/dashboard"
  }

  return next
}

export async function GET(request: Request) {
  const requestUrl = new URL(request.url)
  const code = requestUrl.searchParams.get("code")
  const nextPath = getSafeNextPath(requestUrl.searchParams.get("next"))
  const env = getSupabaseEnv()

  if (!env.isConfigured) {
    return NextResponse.redirect(
      new URL("/login?error=ยังไม่ได้ตั้งค่า Supabase", request.url)
    )
  }

  if (!code) {
    return NextResponse.redirect(
      new URL("/login?error=ไม่พบรหัสยืนยันการเข้าสู่ระบบ", request.url)
    )
  }

  const supabase = await createServerSupabaseClient()

  if (!supabase) {
    return NextResponse.redirect(
      new URL("/login?error=ไม่สามารถเชื่อมต่อ Supabase ได้", request.url)
    )
  }

  const { error } = await supabase.auth.exchangeCodeForSession(code)

  if (error) {
    return NextResponse.redirect(
      new URL("/login?error=เข้าสู่ระบบไม่สำเร็จ กรุณาลองใหม่อีกครั้ง", request.url)
    )
  }

  return NextResponse.redirect(new URL(nextPath, request.url))
}
