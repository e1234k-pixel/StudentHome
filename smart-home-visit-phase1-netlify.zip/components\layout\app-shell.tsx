import Link from "next/link"
import { GraduationCap, LayoutDashboard, LogOut, Upload, Users } from "lucide-react"
import type { ReactNode } from "react"

import { signOutAction } from "@/app/_actions/auth"
import { NavLink } from "@/components/layout/nav-link"
import { SubmitButton } from "@/components/shared/submit-button"
import { Card, CardContent } from "@/components/ui/card"
import type { UserProfile } from "@/types/database"

export function AppShell({
  children,
  profile,
  email,
}: {
  children: ReactNode
  profile: UserProfile | null
  email?: string
}) {
  const displayName = profile?.full_name || email || "ผู้ใช้งาน"

  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top,_rgba(96,165,250,0.25),_transparent_35%),linear-gradient(180deg,_#eff6ff_0%,_#f8fbff_45%,_#ffffff_100%)]">
      <header className="border-b border-blue-100 bg-white/80 backdrop-blur">
        <div className="mx-auto flex max-w-7xl flex-col gap-4 px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-blue-600 text-white shadow-sm">
                <GraduationCap className="h-5 w-5" />
              </div>
              <div>
                <Link
                  href="/dashboard"
                  className="text-lg font-semibold tracking-tight text-slate-900"
                >
                  Smart Home Visit
                </Link>
                <p className="text-sm text-slate-600">
                  ระบบจัดการนักเรียนสำหรับงานเยี่ยมบ้าน
                </p>
              </div>
            </div>

            <Card className="border-blue-100 bg-blue-50/80 py-3 shadow-none">
              <CardContent className="flex flex-col gap-3 px-4 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-800">{displayName}</p>
                  <p className="text-xs uppercase tracking-[0.2em] text-blue-700/80">
                    {profile?.role ?? "guest"}
                  </p>
                </div>
                <form action={signOutAction}>
                  <SubmitButton
                    variant="outline"
                    pendingText="กำลังออกจากระบบ..."
                    className="border-blue-200 bg-white text-slate-700"
                  >
                    <LogOut className="h-4 w-4" />
                    ออกจากระบบ
                  </SubmitButton>
                </form>
              </CardContent>
            </Card>
          </div>

          <nav className="flex flex-wrap gap-3">
            <NavLink href="/dashboard" icon={<LayoutDashboard className="h-4 w-4" />}>
              แดชบอร์ด
            </NavLink>
            <NavLink href="/students" icon={<Users className="h-4 w-4" />}>
              นักเรียน
            </NavLink>
            <NavLink href="/students/import" icon={<Upload className="h-4 w-4" />}>
              นำเข้า Excel
            </NavLink>
          </nav>
        </div>
      </header>

      <main className="mx-auto flex w-full max-w-7xl flex-1 flex-col gap-6 px-4 py-6 sm:px-6 lg:px-8">
        {children}
      </main>
    </div>
  )
}
