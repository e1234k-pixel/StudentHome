import { createServerClient } from "@supabase/ssr"
import type { SupabaseClient } from "@supabase/supabase-js"
import { cookies } from "next/headers"

import { getSupabaseEnv } from "@/lib/supabase/env"
import type { Database } from "@/types/database"

export async function createServerSupabaseClient(): Promise<SupabaseClient<Database> | null> {
  const env = getSupabaseEnv()

  if (!env.isConfigured) {
    return null
  }

  const cookieStore = await cookies()

  return createServerClient<Database>(env.url, env.anonKey, {
    cookies: {
      getAll() {
        return cookieStore.getAll()
      },
      setAll(cookiesToSet) {
        try {
          cookiesToSet.forEach(({ name, value, options }) => {
            cookieStore.set(name, value, options)
          })
        } catch {
          // เรียกจาก Server Component บางกรณีจะ set cookie ไม่ได้ ให้ middleware จัดการแทน
        }
      },
    },
  })
}
