# ไฟล์ที่ต้องเอาขึ้น Netlify

## วิธีที่แนะนำ

โปรเจกต์นี้เป็น `Next.js` แบบมี `middleware`, `auth callback`, `server actions` และหน้า dynamic ดังนั้นวิธีที่ถูกต้องคือ

- push ทั้งโปรเจกต์ขึ้น `GitHub` หรือ `GitLab`
- จากนั้นให้ Netlify ดึงจาก repository

ไม่แนะนำให้อัปแบบลากไฟล์เว็บธรรมดา เพราะระบบนี้ไม่ใช่ static site อย่างเดียว

## ให้อัปอะไรบ้าง

ให้อัปทั้งโปรเจกต์ ยกเว้นไฟล์ที่เป็น cache หรือ dependency ที่สร้างใหม่ได้

ไฟล์และโฟลเดอร์สำคัญที่ต้องมี:

- `app/`
- `components/`
- `hooks/`
- `lib/`
- `supabase/`
- `types/`
- `.eslintrc.json`
- `.gitignore`
- `components.json`
- `middleware.ts`
- `netlify.toml`
- `next.config.ts`
- `package.json`
- `package-lock.json`
- `postcss.config.mjs`
- `tsconfig.json`
- `README.md`

## ไม่ต้องอัป

- `node_modules/`
- `.next/`
- `.env.local`

## Environment Variables

ไฟล์ `.env.local` ไม่ต้องอัปขึ้น Netlify

ให้เอาค่าข้างในไปใส่ใน Netlify แทนที่:

`Site settings` -> `Environment variables`

ค่าที่ต้องใส่:

```env
NEXT_PUBLIC_SUPABASE_URL=https://ivhnjmujtbbjnrrdcqlv.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=sb_publishable_3XuXVJNm_NUSUD_ofgbh4Q_3qhGjXrs
```

## ถ้าจะอัปเป็น zip

ถ้าคุณจะบีบเป็น zip ก่อนส่งต่อหรือเก็บสำรอง ให้ zip ทั้งโปรเจกต์โดยไม่รวม:

- `node_modules/`
- `.next/`
- `.env.local`

## สรุปสั้น

ถ้าจะขึ้น Netlify ให้ใช้ทั้งโปรเจกต์นี้ ไม่ใช่เลือกเฉพาะบางหน้า

สิ่งสำคัญที่สุดคือ:

1. มีไฟล์ `package.json`
2. มีไฟล์ `netlify.toml`
3. มี source code ทั้งโฟลเดอร์
4. ใส่ค่า Supabase ในหน้า Environment Variables ของ Netlify
