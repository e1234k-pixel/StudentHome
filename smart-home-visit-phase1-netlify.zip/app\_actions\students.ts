"use server"

import { revalidatePath } from "next/cache"
import { redirect } from "next/navigation"
import * as XLSX from "xlsx"
import { z } from "zod"

import {
  formatSupabaseError,
  getStudentFormValues,
  mapImportRows,
  toStudentInsert,
} from "@/lib/students"
import { createServerSupabaseClient } from "@/lib/supabase/server"

function redirectWithNotice(
  path: string,
  key: "message" | "error",
  value: string
): never {
  const searchParams = new URLSearchParams({
    [key]: value,
  })

  redirect(`${path}?${searchParams.toString()}`)
}

function ensureId(formData: FormData) {
  return z.string().uuid("ไม่พบรหัสนักเรียนที่ถูกต้อง").parse(formData.get("id"))
}

export async function createStudentAction(formData: FormData) {
  const supabase = await createServerSupabaseClient()

  if (!supabase) {
    redirectWithNotice("/students/new", "error", "ยังไม่ได้ตั้งค่า Supabase")
  }

  try {
    const values = getStudentFormValues(formData)
    const { error } = await supabase.from("students").insert(toStudentInsert(values))

    if (error) {
      redirectWithNotice("/students/new", "error", formatSupabaseError(error.message))
    }
  } catch (error) {
    const message =
      error instanceof z.ZodError
        ? error.issues[0]?.message ?? "ข้อมูลไม่ถูกต้อง"
        : "เกิดข้อผิดพลาดระหว่างบันทึกข้อมูล"

    redirectWithNotice("/students/new", "error", message)
  }

  revalidatePath("/dashboard")
  revalidatePath("/students")
  redirectWithNotice("/students", "message", "เพิ่มข้อมูลนักเรียนเรียบร้อยแล้ว")
}

export async function updateStudentAction(formData: FormData) {
  const supabase = await createServerSupabaseClient()

  if (!supabase) {
    redirectWithNotice("/students", "error", "ยังไม่ได้ตั้งค่า Supabase")
  }

  let studentId = ""

  try {
    studentId = ensureId(formData)
    const values = getStudentFormValues(formData)

    const { error } = await supabase
      .from("students")
      .update(toStudentInsert(values))
      .eq("id", studentId)

    if (error) {
      redirectWithNotice(
        `/students/${studentId}`,
        "error",
        formatSupabaseError(error.message)
      )
    }
  } catch (error) {
    const message =
      error instanceof z.ZodError
        ? error.issues[0]?.message ?? "ข้อมูลไม่ถูกต้อง"
        : "เกิดข้อผิดพลาดระหว่างอัปเดตข้อมูล"

    redirectWithNotice(studentId ? `/students/${studentId}` : "/students", "error", message)
  }

  revalidatePath("/dashboard")
  revalidatePath("/students")
  revalidatePath(`/students/${studentId}`)
  redirectWithNotice(`/students/${studentId}`, "message", "อัปเดตข้อมูลเรียบร้อยแล้ว")
}

export async function deleteStudentAction(formData: FormData) {
  const supabase = await createServerSupabaseClient()

  if (!supabase) {
    redirectWithNotice("/students", "error", "ยังไม่ได้ตั้งค่า Supabase")
  }

  let studentId = ""

  try {
    studentId = ensureId(formData)

    const { error } = await supabase.from("students").delete().eq("id", studentId)

    if (error) {
      redirectWithNotice(
        `/students/${studentId}`,
        "error",
        "ไม่สามารถลบข้อมูลนักเรียนได้"
      )
    }
  } catch {
    redirectWithNotice(studentId ? `/students/${studentId}` : "/students", "error", "ไม่พบรหัสนักเรียน")
  }

  revalidatePath("/dashboard")
  revalidatePath("/students")
  redirectWithNotice("/students", "message", "ลบข้อมูลนักเรียนเรียบร้อยแล้ว")
}

export async function importStudentsAction(formData: FormData) {
  const supabase = await createServerSupabaseClient()

  if (!supabase) {
    redirectWithNotice("/students/import", "error", "ยังไม่ได้ตั้งค่า Supabase")
  }

  const file = formData.get("file")

  if (!(file instanceof File) || file.size === 0) {
    redirectWithNotice("/students/import", "error", "กรุณาเลือกไฟล์ .xlsx หรือ .xls")
  }

  if (!/\.(xlsx|xls)$/i.test(file.name)) {
    redirectWithNotice("/students/import", "error", "รองรับเฉพาะไฟล์ Excel เท่านั้น")
  }

  try {
    const buffer = await file.arrayBuffer()
    const workbook = XLSX.read(buffer, {
      type: "array",
      cellDates: false,
    })

    const firstSheet = workbook.Sheets[workbook.SheetNames[0]]
    const rows = XLSX.utils.sheet_to_json<Record<string, string | number | boolean | null>>(
      firstSheet,
      {
        defval: "",
        raw: false,
      }
    )

    if (rows.length === 0) {
      redirectWithNotice("/students/import", "error", "ไม่พบข้อมูลในไฟล์ที่อัปโหลด")
    }

    const { records, errors } = mapImportRows(rows)

    if (errors.length > 0) {
      redirectWithNotice(
        "/students/import",
        "error",
        `ตรวจพบข้อมูลไม่ถูกต้อง: ${errors.slice(0, 3).join(" | ")}`
      )
    }

    const { error } = await supabase.from("students").upsert(records, {
      onConflict: "student_code",
    })

    if (error) {
      redirectWithNotice("/students/import", "error", formatSupabaseError(error.message))
    }
  } catch {
    redirectWithNotice(
      "/students/import",
      "error",
      "ไม่สามารถอ่านไฟล์ Excel ได้ กรุณาตรวจสอบรูปแบบไฟล์อีกครั้ง"
    )
  }

  revalidatePath("/dashboard")
  revalidatePath("/students")
  redirectWithNotice("/students", "message", `นำเข้าข้อมูลจากไฟล์ ${file.name} เรียบร้อยแล้ว`)
}
