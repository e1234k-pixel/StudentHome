# Supabase Setup Guide

## 1. สร้างโปรเจกต์ Supabase

1. เข้า [Supabase Dashboard](https://supabase.com/)
2. สร้าง Project ใหม่
3. รอจนฐานข้อมูลพร้อมใช้งาน

## 2. เปิด Google Login

1. ไปที่ `Authentication` -> `Providers`
2. เปิด `Google`
3. ใส่ `Client ID` และ `Client Secret` จาก Google Cloud Console
4. เพิ่ม Redirect URL ของโปรเจกต์ เช่น
   - `http://localhost:3000/auth/callback`
   - Production URL ของระบบ `/auth/callback`

## 3. รัน SQL Schema

1. ไปที่ `SQL Editor`
2. เปิดไฟล์ `supabase/schema.sql`
3. คัดลอกทั้งหมดแล้วรัน

Schema นี้จะสร้าง:

- ตาราง `public.users`
- ตาราง `public.students`
- trigger สำหรับ sync โปรไฟล์จาก `auth.users`
- helper functions สำหรับเช็ค role
- RLS policies สำหรับผู้ใช้ที่ login แล้ว
- view `student_dashboard_summary`

## 4. กำหนด Admin คนแรก

หลัง login ด้วย Google ครั้งแรก ระบบจะสร้าง role เป็น `teacher` อัตโนมัติ

ถ้าต้องการเปลี่ยนเป็น admin ให้รัน:

```sql
update public.users
set role = 'admin'
where email = 'your-email@example.com';
```

## 5. Environment Variables

สร้างไฟล์ `.env.local` แล้วใส่ค่า:

```env
NEXT_PUBLIC_SUPABASE_URL=your-supabase-url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-supabase-anon-key
```

## 6. ตรวจสอบการทำงาน

1. Login ด้วย Google
2. ดูว่ามีข้อมูลใน `public.users`
3. ลองเพิ่มนักเรียนใน `public.students`
4. ตรวจสอบว่า Dashboard แสดงจำนวนได้ถูกต้อง

## 7. หมายเหตุสำคัญ

- ใน Phase 1 ยังไม่มี GPS, Route Planner, AI และ PDF Report
- สถิติชาย/หญิงใน Dashboard คำนวณจาก `prefix`
- หากต้องการความแม่นยำเรื่องเพศในอนาคต แนะนำเพิ่มคอลัมน์ `gender` ใน Phase ถัดไป
