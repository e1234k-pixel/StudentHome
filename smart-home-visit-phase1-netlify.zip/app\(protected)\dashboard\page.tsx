import Link from "next/link"
import { ArrowRight, BookOpenCheck, FileSpreadsheet, Users } from "lucide-react"

import { EmptyState } from "@/components/shared/empty-state"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { formatStudentName, formatThaiDate } from "@/lib/students"
import { isSupabaseConfigured, requireSessionContext } from "@/lib/auth"
import { createServerSupabaseClient } from "@/lib/supabase/server"

export const dynamic = "force-dynamic"

export default async function DashboardPage() {
  const configured = isSupabaseConfigured()

  if (!configured) {
    return (
      <EmptyState
        title="ยังไม่สามารถโหลดแดชบอร์ดได้"
        description="กรุณาตั้งค่า NEXT_PUBLIC_SUPABASE_URL และ NEXT_PUBLIC_SUPABASE_ANON_KEY ใน .env.local ก่อนใช้งานจริง"
      />
    )
  }

  const [{ profile }, supabase] = await Promise.all([
    requireSessionContext(),
    createServerSupabaseClient(),
  ])

  if (!supabase) {
    return (
      <EmptyState
        title="เชื่อมต่อ Supabase ไม่สำเร็จ"
        description="ระบบไม่สามารถสร้าง Supabase client ได้ในขณะนี้"
      />
    )
  }

  const [{ data: summary }, { data: recentStudents }] = await Promise.all([
    supabase.from("student_dashboard_summary").select("*").maybeSingle(),
    supabase
      .from("students")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(5),
  ])

  const stats = [
    {
      label: "นักเรียนทั้งหมด",
      value: summary?.total_students ?? 0,
      description: "ข้อมูลจากตาราง public.students",
      icon: <Users className="h-5 w-5" />,
    },
    {
      label: "นักเรียนชาย",
      value: summary?.male_students ?? 0,
      description: "คำนวณจาก prefix",
      icon: <BookOpenCheck className="h-5 w-5" />,
    },
    {
      label: "นักเรียนหญิง",
      value: summary?.female_students ?? 0,
      description: "คำนวณจาก prefix",
      icon: <BookOpenCheck className="h-5 w-5" />,
    },
    {
      label: "จำนวนห้องเรียน",
      value: summary?.total_class_rooms ?? 0,
      description: "นับค่า class_room ที่ไม่ซ้ำกัน",
      icon: <FileSpreadsheet className="h-5 w-5" />,
    },
  ]

  return (
    <div className="space-y-6">
      <section className="grid gap-4 lg:grid-cols-[1.3fr_0.7fr]">
        <Card className="border-blue-100 bg-white/85 shadow-lg shadow-blue-100/30">
          <CardHeader className="space-y-3">
            <Badge className="w-fit rounded-full bg-blue-100 px-3 py-1 text-blue-700 hover:bg-blue-100">
              ภาพรวมระบบ
            </Badge>
            <CardTitle className="text-3xl text-slate-950">
              ยินดีต้อนรับ {profile?.full_name || "คุณครู"}
            </CardTitle>
            <CardDescription className="max-w-2xl text-base leading-7 text-slate-600">
              ตรวจสอบสถิตินักเรียนล่าสุด แล้วไปยังหน้าจัดการข้อมูลหรือนำเข้าไฟล์ Excel
              ได้จากเมนูด้านบน
            </CardDescription>
          </CardHeader>
          <CardContent className="flex flex-wrap gap-3">
            <Link
              href="/students"
              className="inline-flex items-center gap-2 rounded-2xl bg-blue-600 px-5 py-3 text-sm font-medium text-white transition hover:bg-blue-700"
            >
              ดูรายชื่อนักเรียน
              <ArrowRight className="h-4 w-4" />
            </Link>
            <Link
              href="/students/import"
              className="inline-flex items-center gap-2 rounded-2xl border border-blue-200 bg-white px-5 py-3 text-sm font-medium text-slate-700 transition hover:bg-blue-50"
            >
              นำเข้าไฟล์ Excel
            </Link>
          </CardContent>
        </Card>

        <Card className="border-blue-100 bg-gradient-to-br from-blue-600 to-sky-500 text-white shadow-lg shadow-blue-200/60">
          <CardHeader>
            <CardTitle>สถานะบัญชี</CardTitle>
            <CardDescription className="text-blue-100">
              สิทธิ์ปัจจุบันของผู้ใช้ในตาราง public.users
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div>
              <p className="text-sm text-blue-100">Role</p>
              <p className="text-2xl font-semibold uppercase tracking-[0.18em]">
                {profile?.role ?? "teacher"}
              </p>
            </div>
            <p className="text-sm leading-6 text-blue-50">
              หากต้องการสิทธิ์ admin ให้ปรับค่า role ใน Supabase ตามคู่มือ setup ที่มีอยู่ในโฟลเดอร์
              supabase
            </p>
          </CardContent>
        </Card>
      </section>

      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        {stats.map((stat) => (
          <Card
            key={stat.label}
            className="border-blue-100 bg-white/85 shadow-sm shadow-blue-100/40"
          >
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between text-slate-700">
                <CardDescription className="text-sm text-slate-500">
                  {stat.label}
                </CardDescription>
                <div className="rounded-xl bg-blue-50 p-2 text-blue-700">{stat.icon}</div>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-semibold tracking-tight text-slate-950">
                {stat.value}
              </p>
              <p className="mt-2 text-sm text-slate-500">{stat.description}</p>
            </CardContent>
          </Card>
        ))}
      </section>

      <Card className="border-blue-100 bg-white/85 shadow-sm shadow-blue-100/40">
        <CardHeader>
          <CardTitle>นักเรียนที่เพิ่มล่าสุด</CardTitle>
          <CardDescription>
            แสดง 5 รายการล่าสุดจากตารางนักเรียน เพื่อให้ตรวจสอบข้อมูลได้รวดเร็ว
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {recentStudents?.length ? (
            recentStudents.map((student) => (
              <Link
                key={student.id}
                href={`/students/${student.id}`}
                className="flex flex-col gap-2 rounded-2xl border border-blue-100 bg-blue-50/40 px-4 py-4 transition hover:border-blue-200 hover:bg-blue-50 sm:flex-row sm:items-center sm:justify-between"
              >
                <div>
                  <p className="font-medium text-slate-900">{formatStudentName(student)}</p>
                  <p className="text-sm text-slate-600">
                    {student.student_code} • {student.class_room}
                  </p>
                </div>
                <div className="text-sm text-slate-500">{formatThaiDate(student.created_at)}</div>
              </Link>
            ))
          ) : (
            <EmptyState
              title="ยังไม่มีข้อมูลนักเรียน"
              description="เริ่มต้นได้จากการเพิ่มนักเรียนใหม่หรืออัปโหลดไฟล์ Excel"
              action={
                <div className="flex flex-wrap gap-3">
                  <Link
                    href="/students/new"
                    className="inline-flex items-center gap-2 rounded-2xl bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700"
                  >
                    เพิ่มนักเรียน
                  </Link>
                  <Link
                    href="/students/import"
                    className="inline-flex items-center gap-2 rounded-2xl border border-blue-200 bg-white px-4 py-2 text-sm font-medium text-slate-700 hover:bg-blue-50"
                  >
                    นำเข้า Excel
                  </Link>
                </div>
              }
            />
          )}
        </CardContent>
      </Card>
    </div>
  )
}
