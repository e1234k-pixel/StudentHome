import Link from "next/link"
import { ChevronLeft, Trash2 } from "lucide-react"
import { notFound } from "next/navigation"

import { deleteStudentAction, updateStudentAction } from "@/app/_actions/students"
import { EmptyState } from "@/components/shared/empty-state"
import { SubmitButton } from "@/components/shared/submit-button"
import { StudentForm } from "@/components/students/student-form"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { formatThaiDate } from "@/lib/students"
import { isSupabaseConfigured } from "@/lib/auth"
import { createServerSupabaseClient } from "@/lib/supabase/server"

export const dynamic = "force-dynamic"

type StudentDetailPageProps = {
  params: Promise<{ id: string }>
  searchParams: Promise<Record<string, string | string[] | undefined>>
}

function readParam(
  params: Record<string, string | string[] | undefined>,
  key: string
) {
  const value = params[key]
  return Array.isArray(value) ? value[0] : value
}

export default async function StudentDetailPage({
  params,
  searchParams,
}: StudentDetailPageProps) {
  const [{ id }, query] = await Promise.all([params, searchParams])
  const message = readParam(query, "message")
  const error = readParam(query, "error")

  if (!isSupabaseConfigured()) {
    return (
      <EmptyState
        title="ยังไม่สามารถแก้ไขข้อมูลนักเรียนได้"
        description="กรุณาตั้งค่า Supabase environment ก่อนใช้งานหน้ารายละเอียดนักเรียน"
      />
    )
  }

  const supabase = await createServerSupabaseClient()

  if (!supabase) {
    return (
      <EmptyState
        title="เชื่อมต่อฐานข้อมูลไม่สำเร็จ"
        description="ระบบไม่สามารถโหลดข้อมูลนักเรียนที่เลือกได้"
      />
    )
  }

  const { data: student } = await supabase
    .from("students")
    .select("*")
    .eq("id", id)
    .maybeSingle()

  if (!student) {
    notFound()
  }

  return (
    <div className="space-y-6">
      <Link
        href="/students"
        className="inline-flex items-center gap-2 text-sm font-medium text-blue-700 hover:text-blue-800"
      >
        <ChevronLeft className="h-4 w-4" />
        กลับไปหน้ารายชื่อนักเรียน
      </Link>

      {message ? (
        <div className="rounded-2xl border border-blue-200 bg-blue-50 px-4 py-3 text-sm text-blue-800">
          {message}
        </div>
      ) : null}

      {error ? (
        <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
          {error}
        </div>
      ) : null}

      <div className="grid gap-6 xl:grid-cols-[1.2fr_0.8fr]">
        <Card className="border-blue-100 bg-white/90 shadow-sm shadow-blue-100/30">
          <CardHeader>
            <CardTitle className="text-2xl text-slate-950">แก้ไขข้อมูลนักเรียน</CardTitle>
            <CardDescription className="text-base leading-7 text-slate-600">
              อัปเดตข้อมูลนักเรียนและผู้ปกครอง จากนั้นบันทึกการเปลี่ยนแปลงกลับไปยัง Supabase
            </CardDescription>
          </CardHeader>
          <CardContent>
            <StudentForm
              action={updateStudentAction}
              student={student}
              submitText="บันทึกการเปลี่ยนแปลง"
              pendingText="กำลังอัปเดตข้อมูล..."
            />
          </CardContent>
        </Card>

        <div className="space-y-6">
          <Card className="border-blue-100 bg-white/90 shadow-sm shadow-blue-100/30">
            <CardHeader>
              <CardTitle>รายละเอียดปัจจุบัน</CardTitle>
              <CardDescription>ข้อมูลอ้างอิงของนักเรียนรายการนี้</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 text-sm text-slate-600">
              <div className="rounded-2xl border border-blue-100 bg-blue-50/60 p-4">
                <p className="text-xs uppercase tracking-[0.18em] text-blue-700">
                  รหัสนักเรียน
                </p>
                <p className="mt-2 text-lg font-semibold text-slate-950">
                  {student.student_code}
                </p>
              </div>
              <div className="space-y-2">
                <p>เลขบัตรประชาชน: {student.citizen_id}</p>
                <p>ห้องเรียน: {student.class_room}</p>
                <p>เบอร์โทรนักเรียน: {student.phone || "-"}</p>
                <p>ชื่อผู้ปกครอง: {student.parent_name || "-"}</p>
                <p>เบอร์ผู้ปกครอง: {student.parent_phone || "-"}</p>
              </div>
              <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
                <p>สร้างเมื่อ: {formatThaiDate(student.created_at)}</p>
                <p>อัปเดตล่าสุด: {formatThaiDate(student.updated_at)}</p>
              </div>
            </CardContent>
          </Card>

          <Card className="border-red-100 bg-white/90 shadow-sm shadow-red-100/30">
            <CardHeader>
              <CardTitle className="text-red-700">โซนอันตราย</CardTitle>
              <CardDescription>
                เมื่อลบแล้วข้อมูลนักเรียนรายการนี้จะหายไปจากระบบทันที
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form action={deleteStudentAction} className="space-y-3">
                <input type="hidden" name="id" value={student.id} />
                <p className="text-sm leading-6 text-slate-600">
                  แนะนำให้ตรวจสอบรหัสนักเรียนและข้อมูลผู้ปกครองก่อนกดลบข้อมูล
                </p>
                <SubmitButton
                  type="submit"
                  variant="destructive"
                  size="lg"
                  pendingText="กำลังลบข้อมูล..."
                  className="w-full rounded-2xl"
                >
                  <Trash2 className="h-4 w-4" />
                  ลบข้อมูลนักเรียน
                </SubmitButton>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
