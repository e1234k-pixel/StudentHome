import Link from "next/link"
import { ChevronLeft, Download, FileSpreadsheet } from "lucide-react"

import { importStudentsAction } from "@/app/_actions/students"
import { EmptyState } from "@/components/shared/empty-state"
import { ImportStudentsForm } from "@/components/students/import-students-form"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { isSupabaseConfigured } from "@/lib/auth"

export const dynamic = "force-dynamic"

type ImportPageProps = {
  searchParams: Promise<Record<string, string | string[] | undefined>>
}

function readParam(
  params: Record<string, string | string[] | undefined>,
  key: string
) {
  const value = params[key]
  return Array.isArray(value) ? value[0] : value
}

export default async function ImportStudentsPage({
  searchParams,
}: ImportPageProps) {
  const params = await searchParams
  const error = readParam(params, "error")

  if (!isSupabaseConfigured()) {
    return (
      <EmptyState
        title="ยังไม่สามารถนำเข้าข้อมูลได้"
        description="กรุณาตั้งค่า Supabase environment ก่อนใช้งานหน้าการนำเข้า Excel"
      />
    )
  }

  return (
    <div className="space-y-6">
      <Link
        href="/students"
        className="inline-flex items-center gap-2 text-sm font-medium text-blue-700 hover:text-blue-800"
      >
        <ChevronLeft className="h-4 w-4" />
        กลับไปหน้ารายชื่อนักเรียน
      </Link>

      {error ? (
        <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
          {error}
        </div>
      ) : null}

      <div className="grid gap-6 xl:grid-cols-[1fr_0.9fr]">
        <Card className="border-blue-100 bg-white/90 shadow-sm shadow-blue-100/30">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-2xl text-slate-950">
              <FileSpreadsheet className="h-6 w-6 text-blue-600" />
              นำเข้าข้อมูลนักเรียนจาก Excel
            </CardTitle>
            <CardDescription className="text-base leading-7 text-slate-600">
              ระบบจะอ่านชีตแรกของไฟล์ Excel แล้วนำเข้าข้อมูลไปยังตาราง public.students
              แบบ upsert โดยอ้างอิง student_code
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ImportStudentsForm action={importStudentsAction} />
          </CardContent>
        </Card>

        <Card className="border-blue-100 bg-white/90 shadow-sm shadow-blue-100/30">
          <CardHeader>
            <CardTitle>รูปแบบคอลัมน์ที่รองรับ</CardTitle>
            <CardDescription>
              ใช้ชื่อคอลัมน์ภาษาอังกฤษหรือภาษาไทยตามรายการด้านล่าง
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4 text-sm leading-7 text-slate-600">
            <div className="rounded-2xl border border-blue-100 bg-blue-50/60 p-4">
              <p className="font-medium text-slate-900">คอลัมน์จำเป็น</p>
              <p>
                student_code, citizen_id, prefix, first_name, last_name, class_room
              </p>
            </div>
            <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
              <p className="font-medium text-slate-900">คอลัมน์ทางเลือก</p>
              <p>phone, parent_name, parent_phone</p>
            </div>
            <div className="rounded-2xl border border-amber-200 bg-amber-50 p-4 text-amber-900">
              <p className="font-medium">ข้อแนะนำ</p>
              <ul className="mt-2 list-disc space-y-1 pl-5">
                <li>ควรเก็บเลขบัตรประชาชนเป็นข้อความใน Excel เพื่อไม่ให้เลขศูนย์นำหน้าหาย</li>
                <li>หาก student_code ซ้ำ ระบบจะอัปเดตข้อมูลรายการเดิม</li>
                <li>หาก citizen_id ซ้ำกับนักเรียนอื่น ระบบจะไม่สามารถนำเข้าได้</li>
              </ul>
            </div>
            <Link
              href="/students/new"
              className="inline-flex items-center gap-2 rounded-2xl border border-blue-200 bg-white px-4 py-2 font-medium text-blue-700 hover:bg-blue-50"
            >
              <Download className="h-4 w-4" />
              หรือเพิ่มข้อมูลทีละรายการ
            </Link>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
