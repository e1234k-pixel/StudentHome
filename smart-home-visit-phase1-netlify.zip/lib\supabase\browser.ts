import { createBrowserClient } from "@supabase/ssr"

import { assertSupabaseEnv } from "@/lib/supabase/env"
import type { Database } from "@/types/database"

export function createBrowserSupabaseClient() {
  const env = assertSupabaseEnv()

  return createBrowserClient<Database>(env.url, env.anonKey)
}
