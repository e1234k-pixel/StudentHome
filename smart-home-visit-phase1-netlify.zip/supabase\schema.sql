-- Smart Home Visit Management System - Phase 1
-- Stack: Supabase + PostgreSQL
-- หมายเหตุ:
-- 1) ใช้ตาราง public.users เป็น profile table ที่อ้างอิง auth.users
-- 2) role เริ่มต้นเป็น teacher หลัง login ครั้งแรกผ่าน Google
-- 3) Dashboard เพศชาย/หญิงใน Phase 1 สามารถคำนวณจาก prefix ได้

create extension if not exists "pgcrypto";

create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = timezone('utc'::text, now());
  return new;
end;
$$;

create table if not exists public.users (
  id uuid primary key references auth.users (id) on delete cascade,
  email text not null unique,
  full_name text not null default '',
  role text not null default 'teacher' check (role in ('admin', 'teacher')),
  created_at timestamptz not null default timezone('utc'::text, now())
);

comment on table public.users is 'เก็บข้อมูลโปรไฟล์ผู้ใช้งานที่เชื่อมกับ Supabase Auth';

create table if not exists public.students (
  id uuid primary key default gen_random_uuid(),
  student_code text not null unique,
  citizen_id text not null unique,
  prefix text not null,
  first_name text not null,
  last_name text not null,
  class_room text not null,
  phone text,
  parent_name text,
  parent_phone text,
  created_at timestamptz not null default timezone('utc'::text, now()),
  updated_at timestamptz not null default timezone('utc'::text, now())
);

comment on table public.students is 'เก็บข้อมูลนักเรียนสำหรับงานเยี่ยมบ้าน';

create index if not exists students_student_code_idx on public.students (student_code);
create index if not exists students_class_room_idx on public.students (class_room);
create index if not exists students_name_idx on public.students (first_name, last_name);

drop trigger if exists students_set_updated_at on public.students;
create trigger students_set_updated_at
before update on public.students
for each row
execute function public.set_updated_at();

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  google_full_name text;
begin
  google_full_name := coalesce(
    new.raw_user_meta_data ->> 'full_name',
    new.raw_user_meta_data ->> 'name',
    split_part(new.email, '@', 1)
  );

  insert into public.users (id, email, full_name, role)
  values (
    new.id,
    new.email,
    coalesce(google_full_name, ''),
    'teacher'
  )
  on conflict (id) do update
  set
    email = excluded.email,
    full_name = case
      when public.users.full_name is null or public.users.full_name = '' then excluded.full_name
      else public.users.full_name
    end;

  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row
execute function public.handle_new_user();

create or replace function public.current_role()
returns text
language sql
stable
security definer
set search_path = public
as $$
  select role
  from public.users
  where id = auth.uid()
$$;

create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select coalesce(public.current_role() = 'admin', false)
$$;

create or replace function public.is_teacher_or_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select coalesce(public.current_role() in ('admin', 'teacher'), false)
$$;

alter table public.users enable row level security;
alter table public.students enable row level security;

drop policy if exists "Users can read own profile" on public.users;
create policy "Users can read own profile"
on public.users
for select
to authenticated
using (id = auth.uid() or public.is_admin());

drop policy if exists "Users can update own profile" on public.users;
create policy "Users can update own profile"
on public.users
for update
to authenticated
using (id = auth.uid() or public.is_admin())
with check (id = auth.uid() or public.is_admin());

drop policy if exists "Admins can insert profiles" on public.users;
create policy "Admins can insert profiles"
on public.users
for insert
to authenticated
with check (public.is_admin());

drop policy if exists "Admins can manage profiles" on public.users;
create policy "Admins can manage profiles"
on public.users
for all
to authenticated
using (public.is_admin())
with check (public.is_admin());

drop policy if exists "Teachers and admins can read students" on public.students;
create policy "Teachers and admins can read students"
on public.students
for select
to authenticated
using (public.is_teacher_or_admin());

drop policy if exists "Teachers and admins can insert students" on public.students;
create policy "Teachers and admins can insert students"
on public.students
for insert
to authenticated
with check (public.is_teacher_or_admin());

drop policy if exists "Teachers and admins can update students" on public.students;
create policy "Teachers and admins can update students"
on public.students
for update
to authenticated
using (public.is_teacher_or_admin())
with check (public.is_teacher_or_admin());

drop policy if exists "Teachers and admins can delete students" on public.students;
create policy "Teachers and admins can delete students"
on public.students
for delete
to authenticated
using (public.is_teacher_or_admin());

create or replace view public.student_dashboard_summary as
select
  count(*)::int as total_students,
  count(*) filter (where prefix in ('นาย', 'เด็กชาย', 'Mr.', 'Master'))::int as male_students,
  count(*) filter (where prefix in ('นางสาว', 'เด็กหญิง', 'Ms.', 'Miss'))::int as female_students,
  count(distinct class_room)::int as total_class_rooms
from public.students;
