import { redirect } from "next/navigation"
import type { ReactNode } from "react"

import { AppShell } from "@/components/layout/app-shell"
import { getSessionContext, isSupabaseConfigured } from "@/lib/auth"

export const dynamic = "force-dynamic"

export default async function ProtectedLayout({
  children,
}: Readonly<{
  children: ReactNode
}>) {
  const configured = isSupabaseConfigured()
  const session = await getSessionContext()

  if (configured && !session.user) {
    redirect("/login")
  }

  return (
    <AppShell profile={session.profile} email={session.user?.email}>
      {children}
    </AppShell>
  )
}
