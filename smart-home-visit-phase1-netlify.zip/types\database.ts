export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      students: {
        Row: {
          id: string
          student_code: string
          citizen_id: string
          prefix: string
          first_name: string
          last_name: string
          class_room: string
          phone: string | null
          parent_name: string | null
          parent_phone: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          student_code: string
          citizen_id: string
          prefix: string
          first_name: string
          last_name: string
          class_room: string
          phone?: string | null
          parent_name?: string | null
          parent_phone?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: Partial<Database["public"]["Tables"]["students"]["Insert"]>
        Relationships: []
      }
      users: {
        Row: {
          id: string
          email: string
          full_name: string
          role: "admin" | "teacher"
          created_at: string
        }
        Insert: {
          id: string
          email: string
          full_name?: string
          role?: "admin" | "teacher"
          created_at?: string
        }
        Update: Partial<Database["public"]["Tables"]["users"]["Insert"]>
        Relationships: []
      }
    }
    Views: {
      student_dashboard_summary: {
        Row: {
          total_students: number
          male_students: number
          female_students: number
          total_class_rooms: number
        }
        Relationships: []
      }
    }
    Functions: {
      current_role: {
        Args: Record<PropertyKey, never>
        Returns: string
      }
      is_admin: {
        Args: Record<PropertyKey, never>
        Returns: boolean
      }
      is_teacher_or_admin: {
        Args: Record<PropertyKey, never>
        Returns: boolean
      }
    }
  }
}

export type StudentRow = Database["public"]["Tables"]["students"]["Row"]
export type StudentInsert = Database["public"]["Tables"]["students"]["Insert"]
export type StudentUpdate = Database["public"]["Tables"]["students"]["Update"]
export type UserProfile = Database["public"]["Tables"]["users"]["Row"]
export type DashboardSummary =
  Database["public"]["Views"]["student_dashboard_summary"]["Row"]
