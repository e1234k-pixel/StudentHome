import { z } from "zod"

import type { StudentInsert, StudentRow } from "@/types/database"

const optionalText = z
  .string()
  .trim()
  .transform((value) => value || null)

export const studentInputSchema = z.object({
  student_code: z.string().trim().min(1, "กรุณากรอกรหัสนักเรียน"),
  citizen_id: z
    .string()
    .trim()
    .min(1, "กรุณากรอกเลขบัตรประชาชน")
    .min(13, "เลขบัตรประชาชนควรมีอย่างน้อย 13 หลัก"),
  prefix: z.string().trim().min(1, "กรุณาเลือกคำนำหน้า"),
  first_name: z.string().trim().min(1, "กรุณากรอกชื่อ"),
  last_name: z.string().trim().min(1, "กรุณากรอกนามสกุล"),
  class_room: z.string().trim().min(1, "กรุณากรอกชั้นเรียน/ห้อง"),
  phone: optionalText,
  parent_name: optionalText,
  parent_phone: optionalText,
})

export type StudentFormValues = z.infer<typeof studentInputSchema>

type SpreadsheetRow = Record<string, string | number | boolean | null | undefined>

const importColumnAliases: Record<keyof StudentFormValues, string[]> = {
  student_code: ["student_code", "code", "student id", "รหัสนักเรียน"],
  citizen_id: [
    "citizen_id",
    "citizen id",
    "national_id",
    "เลขบัตรประชาชน",
    "เลขประชาชน",
  ],
  prefix: ["prefix", "title", "คำนำหน้า"],
  first_name: ["first_name", "firstname", "first name", "ชื่อ"],
  last_name: ["last_name", "lastname", "last name", "นามสกุล"],
  class_room: ["class_room", "classroom", "class", "ห้อง", "ชั้นเรียน"],
  phone: ["phone", "mobile", "เบอร์โทร", "โทรศัพท์"],
  parent_name: ["parent_name", "guardian_name", "ชื่อผู้ปกครอง", "ผู้ปกครอง"],
  parent_phone: [
    "parent_phone",
    "guardian_phone",
    "เบอร์ผู้ปกครอง",
    "โทรศัพท์ผู้ปกครอง",
  ],
}

export const prefixOptions = ["เด็กชาย", "เด็กหญิง", "นาย", "นางสาว", "Mr.", "Ms."]

export function getStudentFormValues(formData: FormData): StudentFormValues {
  const payload = {
    student_code: String(formData.get("student_code") ?? ""),
    citizen_id: String(formData.get("citizen_id") ?? ""),
    prefix: String(formData.get("prefix") ?? ""),
    first_name: String(formData.get("first_name") ?? ""),
    last_name: String(formData.get("last_name") ?? ""),
    class_room: String(formData.get("class_room") ?? ""),
    phone: String(formData.get("phone") ?? ""),
    parent_name: String(formData.get("parent_name") ?? ""),
    parent_phone: String(formData.get("parent_phone") ?? ""),
  }

  return studentInputSchema.parse(payload)
}

export function toStudentInsert(values: StudentFormValues): StudentInsert {
  return values
}

export function toStudentDefaults(student?: StudentRow | null) {
  return {
    student_code: student?.student_code ?? "",
    citizen_id: student?.citizen_id ?? "",
    prefix: student?.prefix ?? "เด็กชาย",
    first_name: student?.first_name ?? "",
    last_name: student?.last_name ?? "",
    class_room: student?.class_room ?? "",
    phone: student?.phone ?? "",
    parent_name: student?.parent_name ?? "",
    parent_phone: student?.parent_phone ?? "",
  }
}

function normalizeKey(value: string) {
  return value.trim().toLowerCase().replace(/[\s\-./]+/g, "_")
}

function normalizeCell(value: string | number | boolean | null | undefined) {
  return String(value ?? "").trim()
}

function pickImportValue(
  normalizedRow: Record<string, string>,
  aliases: string[]
) {
  for (const alias of aliases) {
    const value = normalizedRow[normalizeKey(alias)]

    if (value) {
      return value
    }
  }

  return ""
}

export function mapImportRows(rows: SpreadsheetRow[]) {
  const records: StudentInsert[] = []
  const errors: string[] = []

  rows.forEach((row, index) => {
    const normalizedRow = Object.entries(row).reduce<Record<string, string>>(
      (accumulator, [key, value]) => {
        accumulator[normalizeKey(key)] = normalizeCell(value)
        return accumulator
      },
      {}
    )

    const parsed = studentInputSchema.safeParse({
      student_code: pickImportValue(
        normalizedRow,
        importColumnAliases.student_code
      ),
      citizen_id: pickImportValue(normalizedRow, importColumnAliases.citizen_id),
      prefix: pickImportValue(normalizedRow, importColumnAliases.prefix),
      first_name: pickImportValue(normalizedRow, importColumnAliases.first_name),
      last_name: pickImportValue(normalizedRow, importColumnAliases.last_name),
      class_room: pickImportValue(normalizedRow, importColumnAliases.class_room),
      phone: pickImportValue(normalizedRow, importColumnAliases.phone),
      parent_name: pickImportValue(normalizedRow, importColumnAliases.parent_name),
      parent_phone: pickImportValue(
        normalizedRow,
        importColumnAliases.parent_phone
      ),
    })

    if (!parsed.success) {
      errors.push(`แถวที่ ${index + 2}: ${parsed.error.issues[0]?.message ?? "ข้อมูลไม่ถูกต้อง"}`)
      return
    }

    records.push(toStudentInsert(parsed.data))
  })

  return { records, errors }
}

export function formatStudentName(student: Pick<StudentRow, "prefix" | "first_name" | "last_name">) {
  return `${student.prefix}${student.first_name} ${student.last_name}`.trim()
}

export function formatThaiDate(date: string) {
  return new Intl.DateTimeFormat("th-TH", {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(new Date(date))
}

export function formatSupabaseError(message: string) {
  if (message.includes("students_student_code_key")) {
    return "รหัสนักเรียนนี้ถูกใช้งานแล้ว"
  }

  if (message.includes("students_citizen_id_key")) {
    return "เลขบัตรประชาชนนี้ถูกใช้งานแล้ว"
  }

  return "ไม่สามารถบันทึกข้อมูลได้ กรุณาตรวจสอบความถูกต้องแล้วลองใหม่อีกครั้ง"
}
