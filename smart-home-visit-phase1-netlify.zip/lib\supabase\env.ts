const missingEnvMessage =
  "ยังไม่ได้ตั้งค่า NEXT_PUBLIC_SUPABASE_URL หรือ NEXT_PUBLIC_SUPABASE_ANON_KEY"

export function getSupabaseEnv() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL?.trim() ?? ""
  const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY?.trim() ?? ""

  return {
    url,
    anonKey,
    isConfigured: Boolean(url && anonKey),
    missingEnvMessage,
  }
}

export function assertSupabaseEnv() {
  const env = getSupabaseEnv()

  if (!env.isConfigured) {
    throw new Error(env.missingEnvMessage)
  }

  return env
}
