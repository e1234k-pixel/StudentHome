import Link from "next/link"
import { Plus, Search, Upload } from "lucide-react"

import { EmptyState } from "@/components/shared/empty-state"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { formatStudentName, formatThaiDate } from "@/lib/students"
import { isSupabaseConfigured } from "@/lib/auth"
import { createServerSupabaseClient } from "@/lib/supabase/server"

export const dynamic = "force-dynamic"

type StudentsPageProps = {
  searchParams: Promise<Record<string, string | string[] | undefined>>
}

function readParam(
  params: Record<string, string | string[] | undefined>,
  key: string
) {
  const value = params[key]
  return Array.isArray(value) ? value[0] : value
}

export default async function StudentsPage({ searchParams }: StudentsPageProps) {
  const params = await searchParams
  const q = readParam(params, "q")?.trim() ?? ""
  const classRoom = readParam(params, "class_room")?.trim() ?? ""
  const message = readParam(params, "message")
  const error = readParam(params, "error")
  const configured = isSupabaseConfigured()

  if (!configured) {
    return (
      <EmptyState
        title="ยังไม่พร้อมใช้งาน"
        description="กรุณาตั้งค่า Supabase environment ก่อนแสดงรายชื่อนักเรียน"
      />
    )
  }

  const supabase = await createServerSupabaseClient()

  if (!supabase) {
    return (
      <EmptyState
        title="เชื่อมต่อฐานข้อมูลไม่สำเร็จ"
        description="ไม่สามารถสร้าง Supabase client เพื่อโหลดข้อมูลนักเรียนได้"
      />
    )
  }

  const { data } = await supabase
    .from("students")
    .select("*")
    .order("created_at", { ascending: false })
    .limit(200)

  const students = data ?? []
  const classRoomOptions = Array.from(
    new Set(students.map((student) => student.class_room))
  ).sort((left, right) => left.localeCompare(right, "th"))

  const filteredStudents = students.filter((student) => {
    const matchesQuery =
      !q ||
      [
        student.student_code,
        student.citizen_id,
        student.first_name,
        student.last_name,
        `${student.first_name} ${student.last_name}`,
      ]
        .join(" ")
        .toLowerCase()
        .includes(q.toLowerCase())

    const matchesClassRoom = !classRoom || student.class_room === classRoom

    return matchesQuery && matchesClassRoom
  })

  return (
    <div className="space-y-6">
      <section className="flex flex-col gap-4 xl:flex-row xl:items-end xl:justify-between">
        <div className="space-y-2">
          <h1 className="text-3xl font-semibold tracking-tight text-slate-950">
            จัดการข้อมูลนักเรียน
          </h1>
          <p className="text-base leading-7 text-slate-600">
            ค้นหา ตรวจสอบ และเข้าไปแก้ไขข้อมูลนักเรียนรายบุคคลได้จากหน้านี้
          </p>
        </div>

        <div className="flex flex-wrap gap-3">
          <Link
            href="/students/new"
            className="inline-flex items-center gap-2 rounded-2xl bg-blue-600 px-5 py-3 text-sm font-medium text-white hover:bg-blue-700"
          >
            <Plus className="h-4 w-4" />
            เพิ่มนักเรียน
          </Link>
          <Link
            href="/students/import"
            className="inline-flex items-center gap-2 rounded-2xl border border-blue-200 bg-white px-5 py-3 text-sm font-medium text-slate-700 hover:bg-blue-50"
          >
            <Upload className="h-4 w-4" />
            นำเข้า Excel
          </Link>
        </div>
      </section>

      {message ? (
        <div className="rounded-2xl border border-blue-200 bg-blue-50 px-4 py-3 text-sm text-blue-800">
          {message}
        </div>
      ) : null}

      {error ? (
        <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
          {error}
        </div>
      ) : null}

      <Card className="border-blue-100 bg-white/85 shadow-sm shadow-blue-100/30">
        <CardHeader>
          <CardTitle>ตัวกรองข้อมูล</CardTitle>
          <CardDescription>
            ระบบจะแสดงข้อมูลล่าสุดสูงสุด 200 รายการ และกรองผลลัพธ์จาก query string
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form className="grid gap-4 lg:grid-cols-[1fr_220px_auto]">
            <div className="space-y-2">
              <label htmlFor="q" className="text-sm font-medium text-slate-700">
                ค้นหาจากชื่อ, รหัสนักเรียน หรือเลขบัตรประชาชน
              </label>
              <div className="relative">
                <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                <Input
                  id="q"
                  name="q"
                  defaultValue={q}
                  className="h-11 rounded-xl border-blue-100 bg-white pl-10"
                  placeholder="พิมพ์คำค้นหา"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label htmlFor="class_room" className="text-sm font-medium text-slate-700">
                ห้องเรียน
              </label>
              <select
                id="class_room"
                name="class_room"
                defaultValue={classRoom}
                className="h-11 w-full rounded-xl border border-blue-100 bg-white px-3 text-sm text-slate-900 outline-none focus:border-blue-400 focus:ring-4 focus:ring-blue-100"
              >
                <option value="">ทุกห้อง</option>
                {classRoomOptions.map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex items-end">
              <button
                type="submit"
                className="inline-flex h-11 items-center justify-center rounded-2xl bg-blue-600 px-5 text-sm font-medium text-white transition hover:bg-blue-700"
              >
                กรองข้อมูล
              </button>
            </div>
          </form>
        </CardContent>
      </Card>

      <Card className="border-blue-100 bg-white/85 shadow-sm shadow-blue-100/30">
        <CardHeader className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <CardTitle>ผลลัพธ์ {filteredStudents.length} รายการ</CardTitle>
            <CardDescription>
              เลือกรายชื่อนักเรียนเพื่อดูรายละเอียดหรือแก้ไขข้อมูล
            </CardDescription>
          </div>
          <div className="text-sm text-slate-500">ข้อมูลทั้งหมดในหน้า: {students.length} รายการ</div>
        </CardHeader>
        <CardContent className="space-y-4">
          {filteredStudents.length ? (
            <>
              <div className="grid gap-3 lg:hidden">
                {filteredStudents.map((student) => (
                  <Link
                    key={student.id}
                    href={`/students/${student.id}`}
                    className="rounded-2xl border border-blue-100 bg-blue-50/40 p-4 transition hover:border-blue-200 hover:bg-blue-50"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <p className="font-medium text-slate-900">{formatStudentName(student)}</p>
                        <p className="text-sm text-slate-600">
                          {student.student_code} • {student.class_room}
                        </p>
                      </div>
                      <span className="rounded-full bg-white px-3 py-1 text-xs font-medium text-blue-700">
                        เปิดดู
                      </span>
                    </div>
                    <div className="mt-4 space-y-1 text-sm text-slate-500">
                      <p>เลขบัตรประชาชน: {student.citizen_id}</p>
                      <p>อัปเดตล่าสุด: {formatThaiDate(student.updated_at)}</p>
                    </div>
                  </Link>
                ))}
              </div>

              <div className="hidden lg:block">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>รหัสนักเรียน</TableHead>
                      <TableHead>ชื่อ-นามสกุล</TableHead>
                      <TableHead>ห้อง</TableHead>
                      <TableHead>เลขบัตรประชาชน</TableHead>
                      <TableHead>ผู้ปกครอง</TableHead>
                      <TableHead>อัปเดตล่าสุด</TableHead>
                      <TableHead className="text-right">จัดการ</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredStudents.map((student) => (
                      <TableRow key={student.id}>
                        <TableCell className="font-medium text-slate-900">
                          {student.student_code}
                        </TableCell>
                        <TableCell>{formatStudentName(student)}</TableCell>
                        <TableCell>{student.class_room}</TableCell>
                        <TableCell>{student.citizen_id}</TableCell>
                        <TableCell>
                          {student.parent_name || "-"}
                          <div className="text-xs text-slate-500">
                            {student.parent_phone || "ไม่มีเบอร์โทร"}
                          </div>
                        </TableCell>
                        <TableCell>{formatThaiDate(student.updated_at)}</TableCell>
                        <TableCell className="text-right">
                          <Link
                            href={`/students/${student.id}`}
                            className="inline-flex items-center rounded-full border border-blue-200 bg-white px-4 py-2 text-sm font-medium text-blue-700 hover:bg-blue-50"
                          >
                            ดูรายละเอียด
                          </Link>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </>
          ) : (
            <EmptyState
              title="ไม่พบนักเรียนตามเงื่อนไข"
              description="ลองเปลี่ยนคำค้นหา หรือลบตัวกรองห้องเรียนเพื่อดูข้อมูลเพิ่มเติม"
            />
          )}
        </CardContent>
      </Card>
    </div>
  )
}
