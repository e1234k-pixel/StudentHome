import { Save } from "lucide-react"

import { SubmitButton } from "@/components/shared/submit-button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { prefixOptions, toStudentDefaults } from "@/lib/students"
import { cn } from "@/lib/utils"
import type { StudentRow } from "@/types/database"

const selectClassName = cn(
  "flex h-11 w-full rounded-xl border border-blue-100 bg-white px-3 text-sm text-slate-900 transition outline-none focus:border-blue-400 focus:ring-4 focus:ring-blue-100"
)

export function StudentForm({
  action,
  student,
  submitText,
  pendingText,
}: {
  action: (formData: FormData) => Promise<void>
  student?: StudentRow | null
  submitText: string
  pendingText: string
}) {
  const defaults = toStudentDefaults(student)

  return (
    <form action={action} className="space-y-6">
      {student ? <input type="hidden" name="id" value={student.id} /> : null}

      <div className="grid gap-5 md:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="student_code">รหัสนักเรียน</Label>
          <Input
            id="student_code"
            name="student_code"
            defaultValue={defaults.student_code}
            className="h-11 rounded-xl border-blue-100 bg-white"
            placeholder="เช่น 65001"
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="citizen_id">เลขบัตรประชาชน</Label>
          <Input
            id="citizen_id"
            name="citizen_id"
            defaultValue={defaults.citizen_id}
            className="h-11 rounded-xl border-blue-100 bg-white"
            placeholder="13 หลัก"
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="prefix">คำนำหน้า</Label>
          <select
            id="prefix"
            name="prefix"
            defaultValue={defaults.prefix}
            className={selectClassName}
            required
          >
            {prefixOptions.map((prefix) => (
              <option key={prefix} value={prefix}>
                {prefix}
              </option>
            ))}
          </select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="class_room">ชั้นเรียน/ห้อง</Label>
          <Input
            id="class_room"
            name="class_room"
            defaultValue={defaults.class_room}
            className="h-11 rounded-xl border-blue-100 bg-white"
            placeholder="เช่น ม.2/1"
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="first_name">ชื่อ</Label>
          <Input
            id="first_name"
            name="first_name"
            defaultValue={defaults.first_name}
            className="h-11 rounded-xl border-blue-100 bg-white"
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="last_name">นามสกุล</Label>
          <Input
            id="last_name"
            name="last_name"
            defaultValue={defaults.last_name}
            className="h-11 rounded-xl border-blue-100 bg-white"
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="phone">เบอร์โทรนักเรียน</Label>
          <Input
            id="phone"
            name="phone"
            defaultValue={defaults.phone}
            className="h-11 rounded-xl border-blue-100 bg-white"
            placeholder="ถ้ามี"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="parent_name">ชื่อผู้ปกครอง</Label>
          <Input
            id="parent_name"
            name="parent_name"
            defaultValue={defaults.parent_name}
            className="h-11 rounded-xl border-blue-100 bg-white"
          />
        </div>

        <div className="space-y-2 md:col-span-2">
          <Label htmlFor="parent_phone">เบอร์โทรผู้ปกครอง</Label>
          <Input
            id="parent_phone"
            name="parent_phone"
            defaultValue={defaults.parent_phone}
            className="h-11 rounded-xl border-blue-100 bg-white"
          />
        </div>
      </div>

      <div className="flex flex-wrap justify-end gap-3">
        <SubmitButton
          type="submit"
          size="lg"
          pendingText={pendingText}
          className="rounded-2xl bg-blue-600 px-6 text-white hover:bg-blue-700"
        >
          <Save className="h-4 w-4" />
          {submitText}
        </SubmitButton>
      </div>
    </form>
  )
}
