import { ArrowRight, ShieldCheck } from "lucide-react"
import { redirect } from "next/navigation"

import { GoogleSignInButton } from "@/components/auth/google-sign-in-button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { getSessionUser, isSupabaseConfigured } from "@/lib/auth"

export const dynamic = "force-dynamic"

type LoginPageProps = {
  searchParams: Promise<Record<string, string | string[] | undefined>>
}

function readParam(
  params: Record<string, string | string[] | undefined>,
  key: string
) {
  const value = params[key]
  return Array.isArray(value) ? value[0] : value
}

export default async function LoginPage({ searchParams }: LoginPageProps) {
  const configured = isSupabaseConfigured()
  const user = await getSessionUser()
  const params = await searchParams
  const nextPath = readParam(params, "next") ?? "/dashboard"
  const message = readParam(params, "message")
  const error = readParam(params, "error")

  if (configured && user) {
    redirect("/dashboard")
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-[radial-gradient(circle_at_top,_rgba(59,130,246,0.18),_transparent_35%),linear-gradient(180deg,_#eff6ff_0%,_#ffffff_100%)] px-4 py-10">
      <div className="grid w-full max-w-6xl gap-8 lg:grid-cols-[1.2fr_0.8fr]">
        <section className="rounded-[32px] border border-blue-100 bg-white/80 p-8 shadow-xl shadow-blue-100/40 backdrop-blur sm:p-10">
          <div className="inline-flex items-center gap-2 rounded-full border border-blue-200 bg-blue-50 px-4 py-2 text-sm font-medium text-blue-700">
            <ShieldCheck className="h-4 w-4" />
            Supabase SSR Authentication
          </div>

          <div className="mt-6 space-y-5">
            <h1 className="max-w-2xl text-4xl font-semibold tracking-tight text-slate-950 sm:text-5xl">
              ระบบจัดการนักเรียนและงานเยี่ยมบ้านที่พร้อมใช้งานบน Next.js
            </h1>
            <p className="max-w-2xl text-lg leading-8 text-slate-600">
              เข้าสู่ระบบด้วย Google ผ่าน Supabase แล้วเริ่มดูแดชบอร์ด, จัดการข้อมูลนักเรียน,
              เพิ่ม-แก้ไข-ลบ และนำเข้าข้อมูลจาก Excel ได้ทันที
            </p>
          </div>

          <div className="mt-8 grid gap-4 sm:grid-cols-3">
            {[
              "SSR auth พร้อม middleware",
              "Student CRUD ครบทุกหน้า",
              "รองรับ import ไฟล์ .xlsx",
            ].map((item) => (
              <div
                key={item}
                className="rounded-2xl border border-blue-100 bg-blue-50/70 p-4 text-sm font-medium text-slate-700"
              >
                {item}
              </div>
            ))}
          </div>
        </section>

        <Card className="border-blue-100 bg-white/90 py-8 shadow-xl shadow-blue-100/40">
          <CardHeader className="space-y-3">
            <CardTitle className="text-2xl text-slate-950">เข้าสู่ระบบ</CardTitle>
            <CardDescription className="text-base leading-7 text-slate-600">
              ใช้ Google Sign-In ตาม schema และ setup guide ที่มีอยู่ในโปรเจกต์
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-5">
            {message ? (
              <div className="rounded-2xl border border-blue-200 bg-blue-50 px-4 py-3 text-sm text-blue-800">
                {message}
              </div>
            ) : null}

            {error ? (
              <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
                {error}
              </div>
            ) : null}

            {!configured ? (
              <div className="space-y-3 rounded-2xl border border-amber-200 bg-amber-50 px-4 py-4 text-sm leading-6 text-amber-900">
                <p className="font-medium">ยังไม่ได้ตั้งค่า Supabase Environment</p>
                <p>
                  กรุณาสร้างไฟล์ <code>.env.local</code> จาก <code>.env.example</code> แล้วเติมค่า
                  URL และ Anon Key ของ Supabase ก่อนใช้งานจริง
                </p>
              </div>
            ) : null}

            <GoogleSignInButton nextPath={nextPath} disabled={!configured} />

            <div className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 text-sm leading-6 text-slate-600">
              หลัง login ครั้งแรก role จะถูกสร้างเป็น <strong>teacher</strong> อัตโนมัติตาม
              <code>supabase/schema.sql</code>
            </div>

            <div className="inline-flex items-center gap-2 text-sm font-medium text-blue-700">
              พร้อมเริ่มใช้งาน
              <ArrowRight className="h-4 w-4" />
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
