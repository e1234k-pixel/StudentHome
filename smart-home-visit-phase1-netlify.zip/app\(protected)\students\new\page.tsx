import Link from "next/link"
import { ChevronLeft } from "lucide-react"

import { createStudentAction } from "@/app/_actions/students"
import { StudentForm } from "@/components/students/student-form"
import { EmptyState } from "@/components/shared/empty-state"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { isSupabaseConfigured } from "@/lib/auth"

export const dynamic = "force-dynamic"

type NewStudentPageProps = {
  searchParams: Promise<Record<string, string | string[] | undefined>>
}

function readParam(
  params: Record<string, string | string[] | undefined>,
  key: string
) {
  const value = params[key]
  return Array.isArray(value) ? value[0] : value
}

export default async function NewStudentPage({
  searchParams,
}: NewStudentPageProps) {
  const params = await searchParams
  const error = readParam(params, "error")

  if (!isSupabaseConfigured()) {
    return (
      <EmptyState
        title="ยังไม่สามารถเพิ่มนักเรียนได้"
        description="กรุณาตั้งค่า Supabase environment ก่อนใช้งานหน้าฟอร์มนี้"
      />
    )
  }

  return (
    <div className="space-y-6">
      <Link
        href="/students"
        className="inline-flex items-center gap-2 text-sm font-medium text-blue-700 hover:text-blue-800"
      >
        <ChevronLeft className="h-4 w-4" />
        กลับไปหน้ารายชื่อนักเรียน
      </Link>

      {error ? (
        <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
          {error}
        </div>
      ) : null}

      <Card className="border-blue-100 bg-white/90 shadow-sm shadow-blue-100/30">
        <CardHeader>
          <CardTitle className="text-2xl text-slate-950">เพิ่มนักเรียนใหม่</CardTitle>
          <CardDescription className="text-base leading-7 text-slate-600">
            กรอกข้อมูลพื้นฐานของนักเรียนและผู้ปกครองเพื่อบันทึกลงตาราง public.students
          </CardDescription>
        </CardHeader>
        <CardContent>
          <StudentForm
            action={createStudentAction}
            submitText="บันทึกนักเรียน"
            pendingText="กำลังบันทึกข้อมูล..."
          />
        </CardContent>
      </Card>
    </div>
  )
}
