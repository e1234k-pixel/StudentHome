"use client"

import { LoaderCircle, LogIn } from "lucide-react"
import { useRouter } from "next/navigation"
import { useMemo, useState, useTransition } from "react"

import { Button } from "@/components/ui/button"
import { createBrowserSupabaseClient } from "@/lib/supabase/browser"

export function GoogleSignInButton({
  nextPath = "/dashboard",
  disabled = false,
}: {
  nextPath?: string
  disabled?: boolean
}) {
  const router = useRouter()
  const [errorMessage, setErrorMessage] = useState("")
  const [isPending, startTransition] = useTransition()

  const callbackUrl = useMemo(() => {
    if (typeof window === "undefined") {
      return ""
    }

    const next = nextPath.startsWith("/") ? nextPath : "/dashboard"
    return `${window.location.origin}/auth/callback?next=${encodeURIComponent(next)}`
  }, [nextPath])

  const onSignIn = () => {
    startTransition(async () => {
      try {
        setErrorMessage("")

        const supabase = createBrowserSupabaseClient()
        const { error } = await supabase.auth.signInWithOAuth({
          provider: "google",
          options: {
            redirectTo: callbackUrl,
          },
        })

        if (error) {
          setErrorMessage(error.message)
        }
      } catch (error) {
        setErrorMessage(
          error instanceof Error ? error.message : "ไม่สามารถเริ่มต้นการเข้าสู่ระบบได้"
        )
      } finally {
        router.refresh()
      }
    })
  }

  return (
    <div className="space-y-3">
      <Button
        type="button"
        size="lg"
        className="w-full justify-center rounded-2xl bg-blue-600 text-white hover:bg-blue-700"
        disabled={disabled || isPending}
        onClick={onSignIn}
      >
        {isPending ? (
          <LoaderCircle className="h-4 w-4 animate-spin" />
        ) : (
          <LogIn className="h-4 w-4" />
        )}
        เข้าสู่ระบบด้วย Google
      </Button>

      {errorMessage ? (
        <p className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
          {errorMessage}
        </p>
      ) : null}
    </div>
  )
}
