"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import type { ReactNode } from "react"

import { cn } from "@/lib/utils"

export function NavLink({
  href,
  icon,
  children,
}: {
  href: string
  icon: ReactNode
  children: ReactNode
}) {
  const pathname = usePathname()
  const isStudentsRoot =
    href === "/students" &&
    (pathname === "/students" ||
      pathname === "/students/new" ||
      /^\/students\/[^/]+$/.test(pathname))

  const isActive =
    isStudentsRoot || pathname === href || pathname.startsWith(`${href}/`)

  return (
    <Link
      href={href}
      className={cn(
        "inline-flex items-center gap-2 rounded-full border px-4 py-2 text-sm font-medium transition",
        isActive
          ? "border-blue-500 bg-blue-600 text-white shadow-sm"
          : "border-blue-100 bg-white/80 text-slate-700 hover:border-blue-200 hover:bg-blue-50"
      )}
    >
      {icon}
      <span>{children}</span>
    </Link>
  )
}
