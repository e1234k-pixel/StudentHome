# Deploy บน Netlify

## สิ่งที่ต้องมี

- โปรเจกต์นี้อยู่บน Git repository
- มี Supabase Project ที่ตั้งค่าเสร็จแล้ว
- เปิด Google Login ใน Supabase และ Google Cloud Console แล้ว

## 1. Push โค้ดขึ้น Git

รองรับได้ทั้ง GitHub, GitLab และ Bitbucket

## 2. Import เข้า Netlify

1. เข้า Netlify
2. กด `Add new site`
3. เลือก `Import an existing project`
4. เลือก repository ของโปรเจกต์นี้

## 3. Build Settings

ถ้า Netlify ไม่อ่าน `netlify.toml` อัตโนมัติ ให้ตั้งค่าดังนี้

- Build command: `npm run build`
- Node version: `20`

ไฟล์ `netlify.toml` ในโปรเจกต์นี้ได้ตั้งค่า build พื้นฐานไว้แล้ว

## 4. Environment Variables

เพิ่มตัวแปรต่อไปนี้ใน Netlify

```env
NEXT_PUBLIC_SUPABASE_URL=https://your-project-ref.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-supabase-anon-key
```

## 5. ตั้งค่า Redirect URLs ใน Supabase

ไปที่ `Supabase Dashboard` -> `Authentication` -> `URL Configuration`

เพิ่ม URL ต่อไปนี้

- `http://localhost:3000/auth/callback`
- `https://your-site-name.netlify.app/auth/callback`

ถ้ามี custom domain ให้เพิ่มด้วย เช่น

- `https://your-domain.com/auth/callback`

## 6. ตั้งค่า Google OAuth

ใน Google Cloud Console ให้เพิ่ม Authorized redirect / allowed origin ตามที่ Supabase และโดเมน Netlify ใช้งานจริง

อย่างน้อยควรตรวจสอบให้ตรงกับ

- Supabase project URL
- Netlify site URL
- custom domain ถ้ามี

## 7. Deploy

หลังตั้งค่า environment variables และ redirect URLs แล้ว ให้กด deploy ใหม่อีกครั้ง

## 8. ตรวจสอบหลัง deploy

1. เปิดหน้า `/login`
2. ลอง login ด้วย Google
3. ตรวจสอบว่า redirect ไป `/dashboard`
4. ทดสอบเพิ่มนักเรียน
5. ทดสอบ import Excel

## หมายเหตุ

- ถ้า login แล้วเด้งกลับหรือ auth ไม่สำเร็จ ส่วนใหญ่เกิดจาก `Redirect URL` ไม่ตรง
- ถ้าเปิดเว็บได้แต่โหลดข้อมูลไม่ได้ ให้ตรวจสอบ env ของ Supabase บน Netlify
- ถ้ามีการเปลี่ยนโดเมน Netlify ต้องกลับไปเพิ่ม URL ใหม่ใน Supabase อีกครั้ง
