"use client"

import { FileSpreadsheet } from "lucide-react"

import { useSelectedFileName } from "@/hooks/use-selected-file-name"
import { SubmitButton } from "@/components/shared/submit-button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

export function ImportStudentsForm({
  action,
}: {
  action: (formData: FormData) => Promise<void>
}) {
  const { fileName, onFileChange } = useSelectedFileName()

  return (
    <form action={action} className="space-y-5">
      <div className="space-y-2">
        <Label htmlFor="file">ไฟล์ Excel</Label>
        <Input
          id="file"
          name="file"
          type="file"
          accept=".xlsx,.xls"
          className="h-11 rounded-xl border-blue-100 bg-white file:mr-3 file:rounded-lg file:bg-blue-50 file:px-3 file:text-blue-700"
          onChange={onFileChange}
          required
        />
        <p className="text-sm text-slate-600">
          รองรับไฟล์ .xlsx และ .xls โดยอ่านข้อมูลจากชีตแรกของไฟล์
        </p>
      </div>

      {fileName ? (
        <div className="rounded-2xl border border-blue-100 bg-blue-50/70 px-4 py-3 text-sm text-blue-800">
          เลือกไฟล์แล้ว: {fileName}
        </div>
      ) : null}

      <div className="flex justify-end">
        <SubmitButton
          type="submit"
          size="lg"
          pendingText="กำลังนำเข้าข้อมูล..."
          className="rounded-2xl bg-blue-600 px-6 text-white hover:bg-blue-700"
        >
          <FileSpreadsheet className="h-4 w-4" />
          เริ่มนำเข้า
        </SubmitButton>
      </div>
    </form>
  )
}
