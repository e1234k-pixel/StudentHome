import type { User } from "@supabase/supabase-js"
import { redirect } from "next/navigation"

import { getSupabaseEnv } from "@/lib/supabase/env"
import { createServerSupabaseClient } from "@/lib/supabase/server"
import type { UserProfile } from "@/types/database"

export function isSupabaseConfigured() {
  return getSupabaseEnv().isConfigured
}

export async function getSessionUser(): Promise<User | null> {
  const supabase = await createServerSupabaseClient()

  if (!supabase) {
    return null
  }

  const {
    data: { user },
  } = await supabase.auth.getUser()

  return user
}

export async function getSessionContext() {
  const supabase = await createServerSupabaseClient()

  if (!supabase) {
    return {
      user: null as User | null,
      profile: null as UserProfile | null,
    }
  }

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    return {
      user: null as User | null,
      profile: null as UserProfile | null,
    }
  }

  const { data: profile } = await supabase
    .from("users")
    .select("*")
    .eq("id", user.id)
    .maybeSingle()

  return {
    user,
    profile: profile ?? null,
  }
}

export async function requireSessionContext() {
  const context = await getSessionContext()

  if (!context.user) {
    redirect("/login")
  }

  return context
}
