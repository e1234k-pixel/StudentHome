"use client"

import { useCallback, useState } from "react"

export function useSelectedFileName() {
  const [fileName, setFileName] = useState("")

  const onFileChange = useCallback(
    (event: React.ChangeEvent<HTMLInputElement>) => {
      setFileName(event.target.files?.[0]?.name ?? "")
    },
    []
  )

  return {
    fileName,
    onFileChange,
  }
}
